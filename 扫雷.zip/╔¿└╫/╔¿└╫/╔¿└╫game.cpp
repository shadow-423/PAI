#define _CRT_SECURE_NO_WARNINGS 1
#include"saolei.h"
void IntChess(char Chess[ROWS][COLS], int rows, int cols ,char set)
{
	int i = 0;
	int j = 0;
	for (i = 0; i < rows; i++)
	{
		for (j = 0; j < cols; j++)
		{
			Chess[i][j] = set;
		}
	}
}
void DisplayChess(char Chess[ROWS][COLS], int row, int col)
{
	int i = 0;
	int j = 0;
	for (i = 0; i <= row; i++)
	{
		if (i>0&&i <=row)
		{
			printf("\n");
			printf(" %3d", i);
		}
		for (j = 0; j <= col; j++)
		{
			if (i == 0)
			{
				if (j <= col)
				{
					printf(" %3d", j);
				}
			}

			else
			{
				if (j > 0 && j <= col)
				{
					printf(" %c ", Chess[i][j]);
				}
				if (j <= col)
				{
					printf("|");
				}
			}
		}
		if (i == 0)
		{
			printf("\n    ");
		}
		for (j = 0; j <= col; j++)
		{
			if (i == 0)
			{
				if (j < col)
				{
					printf("____" );
				}
				if (j == col)
				{
					printf("_");
				}
			}
		}
		if (i > 0)
		{
			printf("\n    ");
			if (i < row)
			{
				for (j = 0; j <= col; j++)
				{
					if (j > 0 && j <= col)
					{
						printf("---");
					}
					if ( j <= col)
					{
						printf("|");
					}
				}
			}
		}
		for (j = 0; j <= col; j++)
		{
			if (i == row)
			{
				if (j < col)
				{
					printf("^^^^");
				}
				if (j == col)
				{
					printf("^");
				}
			}
		}
		if (i == row)
		{
			printf("\n");
		}
	}
}
//������
void SetMine(char mine[ROWS][ROWS], int row, int col)
{
	int count = EASY_COUNT;
	while (count)
	{
		int x = rand() % row + 1;
		int y = rand() % col + 1;
		if (mine[x][y] == '0')
		{
			mine[x][y] = '1';
			count--;
		}
	}
}
//������Χ����
static int get_mine_count(char mine[ROWS][COLS],  int x, int y)
{
	int num = 0;
		num = mine[x - 1][y] +
		      mine[x - 1][y - 1] +
		      mine[x][y - 1] +
		      mine[x + 1][y - 1] +
		      mine[x + 1][y] +
		      mine[x + 1][y + 1] +
		      mine[x][y + 1] +
		      mine[x - 1][y + 1] - 8 * '0';
		return num;
}
//�Ų���
void FindMine(char mine[ROWS][COLS], char show[ROWS][COLS], int row, int col)
{
	int x = 1;
	int y = 1;
	int win = 0;
	printf("��Ϸ��ʼ�����롮0 0��Ͷ����\n");
	while (win<row*col-EASY_COUNT)
	{
		printf("�������Ų��׵����꣺");
		scanf("%d%d", &x, &y);
		int ch;
		while (ch = getchar() != '\n')
		{
			;
		}
		if (x == 0 && y == 0)
		{
			DisplayChess(mine, row, col);
			break;
		}
		int i = x;
		int j = y;
		if (x >= 1 && x <= row && y >= 1 && y <= col && show[x][y] == '*')
		{
			//����Ϸ�
			if (mine[x][y] == '1')
			{
				printf("���ź����㱻ը���ˣ�\n");
				DisplayChess(mine, row, col);
				break;
			}
			else
			{
				//������Χ����
				int count = get_mine_count(mine, x, y);
				if (count == 0)
				{
					show[x][y] = ' ';
				}
				else
				{
					show[x][y] = count + '0';
				}
				DisplayChess(show, row, col);
				win++;
			}
		}
		//���겻�Ϸ�
		else
		{
			printf("����Ƿ������������룡\n");
		}
		if (win == row * col - EASY_COUNT)
		{
			printf("��ϲ��ɹ����ף�����\n");
		}
	}
}